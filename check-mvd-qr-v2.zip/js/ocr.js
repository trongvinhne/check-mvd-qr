// OCR module placeholder
window.OCR={ async scan(){ return []; } };
