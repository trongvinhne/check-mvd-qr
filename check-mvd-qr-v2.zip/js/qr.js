// QR module placeholder
window.QRModule={ generate(){} };
