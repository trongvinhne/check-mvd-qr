// VTP Check V4 - video engine (skeleton)
window.VideoEngine={
  async load(file){ this.file=file; },
  getInfo(){ return {}; }
};
